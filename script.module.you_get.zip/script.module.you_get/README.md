script.module.you_get
======================

Python you_get library packed for KODI.

See https://github.com/soimort/you-get
